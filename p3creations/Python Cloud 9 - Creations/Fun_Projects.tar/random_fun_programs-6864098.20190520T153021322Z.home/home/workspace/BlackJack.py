def Black_Jack():
    Cards = [2,3,4,5,6,7,8,9,10]
    print ("\n")
    print ("Hello welcome to BlackJack, this is a one player game.")
    print ("\n")
    
Black_Jack()