import random
def Main():
    x = 0
    while x == 0:
        User_Input = input("Type [1] and hit enter to generate a random score / 2: ")
        if User_Input == ("1"):
            x = 1
            print ("\n")
            Score = 0
            Random_Point_Giver = [2,6,8,10,12,14,16]
            Added_Bonus = [2,4,6,8,10,12]
            Point = (random.choice(Random_Point_Giver))
            print ("Actual point \n")
            print (Point)
            print ("\n")
            Total_Bonus = (random.choice(Added_Bonus))
            print ("Actual Bonus \n")
            print(Total_Bonus)
            print ("\n")
            print ("Actual Point + Bonus divided by 2 \n")
            Score = Score + Point + Total_Bonus * 1 / 2
            print (Score)
            print ("\n")
            Main()
        else:
            print ("\n")
            print ("Please select an available option.")
            print ("\n")
Main()