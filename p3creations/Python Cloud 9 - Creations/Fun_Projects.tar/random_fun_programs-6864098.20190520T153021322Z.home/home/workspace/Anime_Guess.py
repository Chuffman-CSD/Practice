import random
def Main():
    print ("\n")
    print ("Hello and welcome to the anime guessing game! \n")
    print ("In this game you will be given question and options, pick the best option for the question! \n")
    def Game():
        Name = input("Please enter your name: ")
        print ("Welcome,",Name,"!")
        print ("\n")
    Game()
Main()