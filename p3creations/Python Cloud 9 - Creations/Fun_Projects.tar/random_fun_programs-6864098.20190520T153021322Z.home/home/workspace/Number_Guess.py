import random
from random import randint
def Main():
    print ("Hello and welcome to the [Number Guesser]! \n")
    print ("\n")
    print ("You start off with [3] guesses!")
    def Game():
        Guesses_Left = 3
        N = (random.randint(1,10))
        x = 0
        while x == 0:
            print ("\n")
            User_Guess = int(input("Try and guess the computer's number!: "))
            print ("\n")
            if User_Guess == (N):
                print ("\n")
                print ("----------------------------------------------------------------------")
                print ("Amazing! You guessed the number with only",Guesses_Left,"guesses left!")
                print ("----------------------------------------------------------------------")
                print ("\n")
                Verify1 = input("Would you like to play again [Y]/[N]: ").upper()
                print ("\n")
                if Verify1 == ("Y"):
                    print ("\n")
                    Main()
                elif Verify1 == ("N"):
                    print ("\n")
                    print ("Goodbye!")
                    break
                else:
                    print ("\n")
                    print ("You did not enter [Y] or [N] please do so next time. ")
                    print ("\n")
            else:
                Guesses_Left = Guesses_Left - 1
                if Guesses_Left == 0:
                    print ("\n")
                    print ("You ran out of guesses! The number was",N,"!")
                    print ("\n")
                    Verify2 = input("Would you like to play again [Y]/[N]: ").upper()
                    if Verify2 == ("Y"):
                        print ("\n")
                        Main()
                    elif Verify2 == ("N"):
                        print ("\n")
                        print ("Goodbye!")
                        break
                    else:
                        print ("\n")
                        print ("You did not enter [Y] or [N] please do so next time. ")
                        print ("\n")
                elif Guesses_Left > 0:
                    print ("\n")
                    print ("Incorrect! You now have",Guesses_Left," guesses left!")
                    print ("\n")
    Game()
Main()