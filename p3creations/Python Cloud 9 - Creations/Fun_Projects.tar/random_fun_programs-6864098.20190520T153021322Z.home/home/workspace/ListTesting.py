def Main():
    List = ["Test1","Test2","Test3","Test4"]
    x = 0
    while x == 0:
        Selection = input("Select numbers 0-3 to select a value from the list: ")
        if Selection == ("0"):
            x = 1
            print ("\n")
            print(List[0])
            print("\n")
            Main()
        elif Selection == ("1"):
            x = 1
            print ("\n")
            print(List[1])
            print("\n")
            Main()
        elif Selection == ("2"):
            x = 1
            print ("\n")
            print(List[2])
            print("\n")
            Main()
        elif Selection == ("3"):
            x = 1
            print ("\n")
            print(List[3])
            print("\n")
            Main()
Main()