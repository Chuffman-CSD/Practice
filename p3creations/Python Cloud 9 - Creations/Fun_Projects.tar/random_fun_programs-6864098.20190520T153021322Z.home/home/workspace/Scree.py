def Main():
    print ("\n")
    x = 0
    while x == 0:
        print ("\n")
        Ready = input("Are you ready to Scree [Y]/[N]: ").upper()
        if Ready == ("Y"):
            print ("\n")
            P = 1
            while True:
                print ("SCREEEEEEE")
        elif Ready == ("N"):
            print ("\n")
            Main()
        else:
            print ("\n")
            print ("Press a given option you dingus.")
            print ("\n")
Main()