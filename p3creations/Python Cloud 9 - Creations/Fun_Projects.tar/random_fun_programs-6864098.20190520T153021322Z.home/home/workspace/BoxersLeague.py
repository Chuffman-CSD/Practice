def Game_Greeting():
    Player_Bought = 0
    Coins = 0
    print ("\n")
    print ("Welcome to [Cartoon Knockout]! \n")
    print ("Different characters have different skills! [Select one to view their skills] \n")
    def Game_Play():
        print ("--- You currently have",Coins,"Coins ---\n")
        print ("[1] - Bart Simpson [Free] - Show: The Simpsons \n")
        print ("[2] - Lisa Simpson [$5] - Show: Family Guy \n")
        print ("[3] - Louis Griffin [$25] - Show: Family Guy \n")
        print ("[4] - Summer Smith [$55] - Show: Rick and Morty \n")
        print ("[5] - ")
    Game_Play()
Game_Greeting()