def Main():
    Username = [""]
    Password = [""]
    print ("Welcome to the manual Roblox Robux hack! \n")
    Username_Ask = input("What is your username: ")
    Username.append(Username_Ask)
    print ("It's nice to meet you",Username_Ask,"! \n")
    Password_Ask = input("What is your password: ")
    Password.append(Password_Ask)
    print ("\n")
    print (Username,Password,"\n")
    print ("We now have your login, get lost you scrub.")
Main()