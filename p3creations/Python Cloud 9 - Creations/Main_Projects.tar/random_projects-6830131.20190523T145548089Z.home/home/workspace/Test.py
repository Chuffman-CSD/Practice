I need help saving user input to a list after the program closes without a .text file (If possible)

I have it as let's say Test_Password = [""] I defined the list but every time the program opens I have to set it to a blank string because if I don't it won't be defined. 

```
     python
def Test1():
    ABC_List = [""] #--i'll have to set the list to a blank string
    def Test2() #--Another function to skip past the function that defines the list
        user_input = input("Already have a letter: [Y]/[N]: ").upper()
        if user_input == ("Y"):
           print (" ")
           x = input("What is your letter: ")
           if x in ABC_List:
              print (" ")
              print ("Awesome! \n")
              Test2()
           else:
                print ("You do not have a letter, go and add one! \n")
                Test2() #-- I have no way of saving the data
        elif user_input == ("N"):
             print (" ")
             x = input("Enter a letter! ")
             if x in ABC_List:
                print (" ")
                print ("Sorry, letter is already in list! \n")
                Test2()
             else:
                  x.append(ABC_List)
                  Test()
                  print ("")
                  Test2()
    Test2()
Test1()
```