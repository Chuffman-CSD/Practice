def Test():
    print ("Test Complete.")
Test()