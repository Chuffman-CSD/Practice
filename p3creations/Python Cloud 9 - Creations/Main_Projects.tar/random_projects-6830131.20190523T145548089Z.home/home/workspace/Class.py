class Patient:
    def __init__(self,Firstname = [" "], Lastname = [" "], Patient = Lastname + Firstname, Symptoms = [" "] ,Usernames = [" "], Passwords = [" "]):
        self.Patient = Patient
        self.Symptoms = Symptoms
        self.Usernames = Usernames 
        self.Passwords = Passwords
def Add_Patient():
    Firstname_Input = input("Enter the patients firstname: )
    Lastname_Input = input("Enter the patients lastname: ")
    Firstname_Input = self.Firstname
    Lastname_Input = self.Lastname
Add_Patient()