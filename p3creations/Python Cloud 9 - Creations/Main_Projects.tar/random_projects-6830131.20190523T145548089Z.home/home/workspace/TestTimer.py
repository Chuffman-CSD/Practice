import time
Time_Left = 5
print ("Redirection to the main menu in: \n")
print (Time_Left,"\n")
Time_Left = Time_Left -1
time.sleep(1)
#------
print (Time_Left,"\n")
Time_Left = Time_Left -1
time.sleep(1)
#------
print (Time_Left,"\n")
Time_Left = Time_Left -1
time.sleep(1)
#------
print (Time_Left,"\n")
Time_Left = Time_Left -1
time.sleep(1)
#------
print (Time_Left,"\n")
Time_Left = Time_Left -1
time.sleep(1)

