Welcome = input("Enter [hi]: ").capitalize()
print (Welcome)