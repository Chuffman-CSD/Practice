#----This is coded in Python 3----
import time # This imports time which allows you to count up or down by using numbers and a timer.
def Login_F(): #--- I define the function Login_F() here
    #----User_Information----#
    Patient_First_Name = ["John"] # This is the Patients first name
    Patient_Last_Name = ["Doe"] # This is the Patients last name
    Patient_List = Patient_First_Name + Patient_Last_Name # This is the Patients first and last name combined into one list when printing the patients first and last name together
    #----Account_Information----#
    Doctor_User = ["Admin"] # This is the set username for a doctor (You can still register but this was a quicker way to test the code since it all goes to the same place when you register then login)
    Doctor_Password_L = ["Admin123"] # This is the set doctor password, every docotr will get an admin code the is the same so nobody who is not a doctor can make a doctor account
    Patient_User = ["Test1"] # This is the Patients set username (You can still register just this way would be faster when loggin in)
    Patient_Password = ["Test2"] # This is the Patients set password (You can still register just this way would be faster when loggin in)
    Admin_Code = ["Z58ieq13"] # This is the set doctor admin code, every docotr will get an admin code the is the same so nobody who is not a doctor can make a doctor account
    #----Medications_Lists----#
    Liquid_Sleep_Medications = ["ZzzQuil","Sleep-Aid"] #This is a list with a few medications that I was testing so that I could check if items were already in the list as well as checking if I could add more items
    Solid_Sleep_Medications = ["Unisom","Sleep-eze","Sleep-Aid","ZzzQuil"] #This is a list with a few medications that I was testing so that I could check if items were already in the list as well as checking if I could add more items
    Liquid_Fever_Medications = [""] #This is a list with no medications that I was testing so that I could check if items were already in the list as well as checking if I could add more items
    Solid_Fever_Medications = [""] #This is a list with no medications that I was testing so that I could check if items were already in the list as well as checking if I could add more items
    Topical_Itching_Medications = ["diphenhydramine"] #This is a list with a few medications that I was testing so that I could check if items were already in the list as well as checking if I could add more items
    #---spacer---#
    def Login_T(): #--- I defined the function Login_T here so that when the user registers an account they are redirected to Login_T, if they register and I have them go to Login_F the lists will be set back to a blank string and the registration will have been for nothing.
        Break = 0
        print ("Hello and welcome to the virtual healthcare app! \n")
        print ("Do you currently have an account with us? \n")
        x = 0
        while x == 0:
            Login_Selection1 = input("[Yes]/[No]: ")
            if Login_Selection1 == ("Yes") or Login_Selection1 == ("yes") or Login_Selection1 == ("Y") or Login_Selection1 == ("y"):
                x = 1
                print (" ")
                x = 0
                while x == 0:
                    Login_Selection2 = input("So you have an account, are you a [Doctor] or a [Patient]: ")
                    if Login_Selection2 == ("Doctor") or Login_Selection2 == ("doctor") or Login_Selection2 == ("D") or Login_Selection2 == ("d"):
                        x = 1
                        print (" ")
                        x = 0
                        while x == 0:
                            Doctor_User_Login = input("Enter your username: ")
                            if Doctor_User_Login in Doctor_User:
                                print (" ")
                                print ("Username: ",Doctor_User_Login)
                                Doctor_Password_Login = input("Enter your password: ")
                                if Doctor_Password_Login in Doctor_Password_L:
                                    x = 1
                                    print (" ")
                                    print ("Password: ",Doctor_Password_Login)
                                    print ("Welcome Doctor",Doctor_User_Login)
                                    print ("Test complete!")
                                    def Doctor_MAIN():
                                        print (" ")
                                        print ("Welcome to the [Doctor Databse] here is a list of available options: \n")
                                        def Doctor_DB():
                                            print ("\n")
                                            print ("---Doctor Databse---")
                                            print ("\n")
                                            print ("[1] - Patient List \n")
                                            print ("[2] - Available Medications \n")
                                            print ("[3] - Add Global Medications \n")
                                            print ("[4] - Log Out \n")
                                            x = 0
                                            while x == 0:
                                                Doctor_Input = input("Enter a selection: ")
                                                print ("\n")
                                                if Doctor_Input == ("1"):
                                                    x = 1
                                                    if Patient_First_Name == ("Jhon") and Patient_Last_Name == ("Doe") or Patient_List == Patient_First_Name == ("Jhon") + Patient_Last_Name == ("Doe"):
                                                        print ("\n")
                                                        print ("There are currently no registered patients.")
                                                        print ("\n")
                                                        Doctor_DB()
                                                    else:
                                                        x = 1
                                                        print ("\n")
                                                        print ("Patients: ",Patient_List)
                                                        print ("\n")
                                                        Doctor_DB()
                                                elif Doctor_Input == ("2"):
                                                    x = 1
                                                    def Medications_Options():
                                                        print ("\n")
                                                        print ("What type of medication are you looking for? \n")
                                                        print ("[1] - Liquid Medication - (Drinkable substances) \n")
                                                        print ("[2] - Solid Medication - (Pills, Vitamins etc.) \n")
                                                        print ("[3] - Topical Medications - (Creams, lotions, ointments)\n")
                                                        print ("[4] - Back. \n")
                                                        x = 0
                                                        while x == 0:
                                                            Medication_Selection = input("Please choose a selection: ")
                                                            if Medication_Selection == ("1"):
                                                                print ("\n")
                                                                print ("You have chosen liquid medication, is this correct? \n")
                                                                x = 0
                                                                while x == 0:
                                                                    True_False4 = input("[Y]/[N]: ").upper()
                                                                    if True_False4 == ("Y"):
                                                                        x = 1
                                                                        print ("\n")
                                                                        print ("[1] - Liquid Fever Medication \n")
                                                                        print ("[2] - Liquid Sleep Medication \n")
                                                                        print ("[3] - Topical itch-Relieving Medication \n")
                                                                        print ("[4] - Back. \n")
                                                                        x = 0
                                                                        while x == 0:
                                                                            Specific_Medication1 = input("Please select an option: ")
                                                                            if Specific_Medication1 == ("1"):
                                                                                x = 1
                                                                                print ("\n")
                                                                                print ("This is all of the [Liquid] Fever Medications we have in our database: ")
                                                                                print ("\n")
                                                                                print (Liquid_Fever_Medications)
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            elif Specific_Medication1 == ("2"):
                                                                                x = 1
                                                                                print ("\n")
                                                                                print ("This is all of the [Liquid] Sleep Medications we have in our database: ")
                                                                                print ("\n")
                                                                                print (Liquid_Sleep_Medications)
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            elif Specific_Medication1 == ("3"):
                                                                                x = 1
                                                                                print ("\n")
                                                                                print ("This is all of the [Topical] itch-releiving Medications we have in our database: ")
                                                                                print ("\n")
                                                                                print (Topical_Itching_Medications)
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            elif Specific_Medication1 == ("4"):
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            else:
                                                                                print ("\n")
                                                                                print ("Please select an available option.")
                                                                                print ("\n")
                                                                    elif True_False4 == ("N"):
                                                                        x = 1
                                                                        print ("\n")
                                                                        Medications_Options()
                                                                    else:
                                                                        print ("\n")
                                                                        print ("Please type one of the given options. ")
                                                                        print ("\n")
                                                            elif Medication_Selection == ("2"):
                                                                print ("\n")
                                                                print ("You have chosen solid medication, is this correct? \n")
                                                                x = 0
                                                                while x == 0:
                                                                    True_False_5 = input("[Y]/[N]: ").upper()
                                                                    if True_False_5 == ("Y"):
                                                                        x = 1
                                                                        print ("\n")
                                                                        print ("[1] - Solid Fever Medication \n")
                                                                        print ("[2] - Solid Sleep Medication \n")
                                                                        print ("[3] - Topical itch-Relieving Medication \n")
                                                                        print ("[4] - Back. \n")
                                                                        x = 0
                                                                        while x == 0:
                                                                            Specific_Medication2 = input("Please select an option: ")
                                                                            if Specific_Medication2 == ("1"):
                                                                                x = 1
                                                                                print ("\n")
                                                                                print ("This is all of the [Solid] Fever Medications we have in our database: ")
                                                                                print ("\n")
                                                                                print (Solid_Fever_Medications)
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            elif Specific_Medication2 == ("2"):
                                                                                x = 1
                                                                                print ("\n")
                                                                                print ("This is all of the [Solid] Sleep Medications we have in our database: ")
                                                                                print ("\n")
                                                                                print (Solid_Fever_Medications)
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            elif Specific_Medication2 == ("3"):
                                                                                x = 1
                                                                                print ("\n")
                                                                                print ("This is all of the [Topical] itch-releiving Medications we have in our database: ")
                                                                                print ("\n")
                                                                                print (Topical_Itching_Medications)
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            elif Specific_Medication2 == ("4"):
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            else:
                                                                                print ("\n")
                                                                                print ("Please select an available option.")
                                                                                print ("\n")
                                                                    elif True_False_5 == ("N"):
                                                                        x = 1
                                                                        print ("\n")
                                                                        Medications_Options()
                                                                    else:
                                                                        print ("\n")
                                                                        print ("Please type one of the given options. ")
                                                                        print ("\n")
                                                            elif Medication_Selection == ("3"):
                                                                print ("\n")
                                                                print ("You have chosen itch-releiving Medication, is this correct? \n")
                                                                x = 0
                                                                while x == 0:
                                                                    True_False6 = input("[Y]/[N]: ").upper()
                                                                    if True_False6 == ("Y"):
                                                                        x = 1
                                                                        print ("\n")
                                                                        print ("\n")
                                                                        print ("[1] - Topical itch-Relieving Medication \n")
                                                                        print ("[2] - Back. \n")
                                                                        x = 0
                                                                        while x == 0:
                                                                            Specific_Medication3 = input("Please select an option: ")
                                                                            if Specific_Medication3 == ("1"):
                                                                                print ("\n")
                                                                                print ("This is all of the [Topical] itch-releiving Medications we have in our database: ")
                                                                                print ("\n")
                                                                                print (Topical_Itching_Medications)
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                            elif Specific_Medication3 == ("2"):
                                                                                print ("\n")
                                                                                Medications_Options()
                                                                    elif True_False6 == ("N"):
                                                                        print ("\n")
                                                                        Medications_Options()
                                                                else:
                                                                    print ("\n")
                                                                    print ("Please type one of the given options. ")
                                                                    print ("\n")
                                                            elif Medication_Selection == ("4"):
                                                                print ("\n")
                                                                Doctor_DB()
                                                            else:
                                                                print ("\n")
                                                                print ("Please type one of the given options. ")
                                                                print ("\n")
                                                    Medications_Options()
                                                elif Doctor_Input == ("3"):
                                                    x = 1
                                                    print ("\n")
                                                    x = 0
                                                    while x == 0:
                                                        Add_Medication1 = input("Please enter the name of the medication: ")
                                                        if Add_Medication1 == ("") or Add_Medication1 == (" "):
                                                            x = 1
                                                            print ("\n")
                                                            print ("You have entered a blank string, please refrain from doing so.")
                                                            print ("\n")
                                                            Doctor_DB()
                                                        else:
                                                            print ("\n")
                                                            print ("Please select what type of medication it is from the list below. \n")
                                                            print ("[1] - Liquid Sleep Medication (Such as a drinkable substance) \n")
                                                            print ("[2] - Liquid Fever Medication (Such as a drinkable substance) \n")
                                                            print ("[3] - Solid Sleep Medication (Such as tablets / pills) \n")
                                                            print ("[4] - Solid Fever Medication (Such as tablets / pills) \n")
                                                            print ("[5] - Topical relieve-itching Medication (Such as lotion / cream) \n")
                                                            print ("[6] - Back.")
                                                            print (" \n")
                                                            x = 0
                                                            while x == 0:
                                                                Add_Medication2 = input("Please select an option: ")
                                                                if Add_Medication2 == ("1"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        True_False4 = input("Is this true, Liquid Sleep Medication [Y]/[N]: ").capitalize()
                                                                        if True_False4 == ("Y"):
                                                                            print ("\n")
                                                                            Liquid_Sleep_Medications.append(Add_Medication1)
                                                                            print ("Liquid Sleep medication added!")
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        elif True_False4 == ("N"):
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        else:
                                                                            print ("\n")
                                                                            print ("Please select an available option.")
                                                                            print ("\n")
                                                                elif Add_Medication2 == ("2"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        True_False5 = input("Is this true, Liquid Fever Medication [Y]/[N]: ").capitalize()
                                                                        if True_False5 == ("Y"):
                                                                            print ("\n")
                                                                            Liquid_Fever_Medications.append(Add_Medication1)
                                                                            print ("Liquid Fever medication added!")
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        elif True_False5 == ("N"):
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        else:
                                                                            print ("\n")
                                                                            print ("Please select an available option.")
                                                                            print ("\n")
                                                                elif Add_Medication2 == ("3"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        True_False6 = input("Is this true, Solid Sleep Medication [Y]/[N]: ").capitalize()
                                                                        if True_False6 == ("Y"):
                                                                            print ("\n")
                                                                            Solid_Sleep_Medications.append(Add_Medication1)
                                                                            print ("Solid Sleep medication added!")
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        elif True_False6 == ("N"):
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        else:
                                                                            print ("\n")
                                                                            print ("Please select an available option.")
                                                                            print ("\n")
                                                                elif Add_Medication2 == ("4"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        True_False7 = input("Is this true, Solid Fever Medication [Y]/[N]: ").capitalize()
                                                                        if True_False7 == ("Y"):
                                                                            print ("\n")
                                                                            Solid_Fever_Medications.append(Add_Medication1)
                                                                            print ("Solid Fever medication added!")
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        elif True_False7 == ("N"):
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        else:
                                                                            print ("\n")
                                                                            print ("Please select an available option.")
                                                                            print ("\n")
                                                                elif Add_Medication2 == ("5"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        True_False8 = input("Is this true, Relieve-itching Medication [Y]/[N]: ").capitalize()
                                                                        if True_False8 == ("Y"):
                                                                            print ("\n")
                                                                            Topical_Itching_Medications.append(Add_Medication1)
                                                                            print ("relieve-itching medication added!")
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        elif True_False8 == ("N"):
                                                                            print ("\n")
                                                                            Doctor_DB()
                                                                        else:
                                                                            print ("\n")
                                                                            print ("Please select one of the available options.")
                                                                            print ("\n")
                                                                elif Add_Medication2 == ("6"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    Doctor_DB()
                                                                else:
                                                                    print ("\n")
                                                                    print ("Please select one of the available options.")
                                                                    print ("\n")
                                                elif Doctor_Input == ("4"):
                                                    x = 1
                                                    print ("\n")
                                                    Login_T()
                                                else:
                                                    print ("\n")
                                                    print ("You did not enter a value [1-5]: ")
                                                    print ("\n")
                                        Doctor_DB()
                                    Doctor_MAIN()
                            else:
                                print ("We do not have a username under",Doctor_User_Login,"\n")
                                print ("Please make an account \n")
                                Login_T()
                    elif Login_Selection2 == ("Patient") or Login_Selection2 == ("patient") or Login_Selection2 == ("P") or Login_Selection2 == ("p"):
                        x = 1
                        print ("\n")
                        x = 0
                        while x == 0:
                            Patient_Username_Login = input("Enter your username: ")
                            if Patient_Username_Login in Patient_User:
                                print ("\n")
                                x = 1
                                w = 0
                                while w == 0:
                                    Patient_Password_Login = input("Enter your password: ")
                                    if Patient_Password_Login in Patient_Password:
                                        w = 1
                                        print ("\n")
                                        print ("Password: ",Patient_Password_Login)
                                        print ("Welcome",Patient_Username_Login)
                                        print ("\n")
                                        def Patient_Menu():
                                            print ("\n")
                                            print ("[1] - Available Medications \n")
                                            print ("[2] - Log Out \n")
                                            x = 0
                                            while x == 0:
                                                Patient_Selection = input("Please select an option: ")
                                                if Patient_Selection == ("1"):
                                                    print ("\n")
                                                    print ("What type of medication are you looking for? \n")
                                                    print ("[1] - Liquid Medication - (Drinkable substances) \n")
                                                    print ("[2] - Solid Medication - (Pills, Vitamins etc.) \n")
                                                    print ("[3] - Topical Medications - (Creams, lotions, ointments)\n")
                                                    print ("[4] - Back. \n")
                                                    x = 0
                                                    while x == 0:
                                                        Medication_Selection = input("Please choose a selection: ")
                                                        if Medication_Selection == ("1"):
                                                            print ("\n")
                                                            print ("You have chosen liquid medication, is this correct? \n")
                                                            x = 0
                                                            while x == 0:
                                                                True_False4 = input("[Y]/[N]: ").upper()
                                                                if True_False4 == ("Y"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    print ("[1] - Liquid Fever Medication \n")
                                                                    print ("[2] - Liquid Sleep Medication \n")
                                                                    print ("[3] - Topical itch-Relieving Medication \n")
                                                                    print ("[4] - Back. \n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        Specific_Medication1 = input("Please select an option: ")
                                                                        if Specific_Medication1 == ("1"):
                                                                            x = 1
                                                                            print ("\n")
                                                                            print ("This is all of the [Liquid] Fever Medications we have in our database: ")
                                                                            print ("\n")
                                                                            print (Liquid_Fever_Medications)
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        elif Specific_Medication1 == ("2"):
                                                                            x = 1
                                                                            print ("\n")
                                                                            print ("This is all of the [Liquid] Sleep Medications we have in our database: ")
                                                                            print ("\n")
                                                                            print (Liquid_Sleep_Medications)
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        elif Specific_Medication1 == ("3"):
                                                                            x = 1
                                                                            print ("\n")
                                                                            print ("This is all of the [Topical] itch-releiving Medications we have in our database: ")
                                                                            print ("\n")
                                                                            print (Topical_Itching_Medications)
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        elif Specific_Medication1 == ("4"):
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        else:
                                                                            print ("\n")
                                                                            print ("Please select an available option.")
                                                                            print ("\n")
                                                                elif True_False4 == ("N"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    Patient_Menu()
                                                                else:
                                                                    print ("\n")
                                                                    print ("Please type one of the given options. ")
                                                                    print ("\n")
                                                        elif Medication_Selection == ("2"):
                                                            print ("\n")
                                                            print ("You have chosen solid medication, is this correct? \n")
                                                            x = 0
                                                            while x == 0:
                                                                True_False_5 = input("[Y]/[N]: ").upper()
                                                                if True_False_5 == ("Y"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    print ("[1] - Solid Fever Medication \n")
                                                                    print ("[2] - Solid Sleep Medication \n")
                                                                    print ("[3] - Topical itch-Relieving Medication \n")
                                                                    print ("[4] - Back. \n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        Specific_Medication3 = input("Please select an option: ")
                                                                        if Specific_Medication3 == ("1"):
                                                                            x = 1
                                                                            print ("\n")
                                                                            print ("This is all of the [Solid] Fever Medications we have in our database: ")
                                                                            print ("\n")
                                                                            print (Solid_Fever_Medications)
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        elif Specific_Medication3 == ("2"):
                                                                            x = 1
                                                                            print ("\n")
                                                                            print ("This is all of the [Solid] Sleep Medications we have in our database: ")
                                                                            print ("\n")
                                                                            print (Solid_Fever_Medications)
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        elif Specific_Medication3 == ("3"):
                                                                            x = 1
                                                                            print ("\n")
                                                                            print ("This is all of the [Topical] itch-releiving Medications we have in our database: ")
                                                                            print ("\n")
                                                                            print (Topical_Itching_Medications)
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        elif Specific_Medication3 == ("4"):
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        else:
                                                                            print ("\n")
                                                                            print ("Please select an available option.")
                                                                            print ("\n")
                                                                elif True_False_5 == ("N"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    Patient_Menu()
                                                                else:
                                                                    print ("\n")
                                                                    print ("Please type one of the given options. ")
                                                                    print ("\n")
                                                        elif Medication_Selection == ("3"):
                                                            print ("\n")
                                                            print ("You have chosen itch-releiving Medication, is this correct? \n")
                                                            x = 0
                                                            while x == 0:
                                                                True_False6 = input("[Y]/[N]: ").upper()
                                                                if True_False6 == ("Y"):
                                                                    x = 1
                                                                    print ("\n")
                                                                    print ("\n")
                                                                    print ("[1] - Topical itch-Relieving Medication \n")
                                                                    print ("[2] - Back. \n")
                                                                    x = 0
                                                                    while x == 0:
                                                                        Specific_Medication3 = input("Please select an option: ")
                                                                        if Specific_Medication3 == ("1"):
                                                                            print ("\n")
                                                                            print ("This is all of the [Topical] itch-releiving Medications we have in our database: ")
                                                                            print ("\n")
                                                                            print (Topical_Itching_Medications)
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                        elif Specific_Medication3 == ("2"):
                                                                            print ("\n")
                                                                            Patient_Menu()
                                                                elif True_False6 == ("N"):
                                                                    print ("\n")
                                                                    Patient_Menu()
                                                            else:
                                                                print ("\n")
                                                                print ("Please type one of the given options. ")
                                                                print ("\n")
                                                        elif Medication_Selection == ("4"):
                                                            print ("\n")
                                                            Patient_Menu()
                                                        else:
                                                            print ("\n")
                                                            print ("Please type one of the given options. ")
                                                            print ("\n")
                                                elif Patient_Selection == ("2"):
                                                    print ("\n")
                                                    Login_T()
                                                else:
                                                    print ("\n")
                                                    print ("Please select an available option.")
                                                    print ("\n")
                                        Patient_Menu()
                                    else:
                                        print ("Please re-enter your password: ")
                                        print ("\n")
                                        Break = Break + 1
                                        if Break == 3:
                                            w = 1
                                            print ("\n")
                                            print ("You have entered the wrong password [",Break,"] amount of times so the code has ended.")
                                            break
                            elif Patient_Username_Login == ("Back") or Patient_Username_Login == ("back") or Patient_Username_Login == ("b") or Patient_Username_Login == ("B"):
                                print ("\n")
                                Login_T()
                            else:
                                print ("\n")
                                print ("We do not have an account with the username [",Patient_Username_Login,"] If you are stuck type [Back] to go back.")
                                print ("\n")
                                if Break == 3 or Break > 3:
                                    x = 1
                                    break
                    elif Login_Selection2 == ("Back") or Login_Selection2 == ("back") or Login_Selection2 == ("b"):
                        x = 1
                        print ("\n")
                        Login_T()
            elif Login_Selection1 == ("No") or Login_Selection1 == ("no") or Login_Selection1 == ("N") or Login_Selection1 == ("n"):
                x = 1
                print (" ")
                Register = input("So you do not have an account, are you a [Doctor] or a [Patient]: ")
                if Register == ("Doctor") or Register == ("doctor"):
                    print (" ")
                    Doctor_Verification = input("Please enter the admin code: ")
                    if Doctor_Verification in (Admin_Code):
                        print (" ")
                        Doctor_Register_Username = input("Welcome, please register a username: ")
                        print ("Username: ",Doctor_Register_Username,"\n")
                        Doctor_User.append(Doctor_Register_Username)
                        Doctor_Password = input("Please register a password: ")
                        print ("Password: ",Doctor_Password,"\n")
                        x = 0
                        while x == 0:
                            Doctor_Password_Verify = input("Re-enter your password: ")
                            if Doctor_Password_Verify == Doctor_Password:
                                Doctor_Password_L.append(Doctor_Password)
                                x = 1
                                print ("\n")
                                print ("Alright! Your account is now set",Doctor_Register_Username,"!","\n")
                                Time_Left = 5
                                print ("Redirection to the main menu in: \n")
                                print (Time_Left,"\n")
                                Time_Left = Time_Left -1
                                time.sleep(1)
                                #------
                                print (Time_Left,"\n")
                                Time_Left = Time_Left -1
                                time.sleep(1)
                                #------
                                print (Time_Left,"\n")
                                Time_Left = Time_Left -1
                                time.sleep(1)
                                #------
                                print (Time_Left,"\n")
                                Time_Left = Time_Left -1
                                time.sleep(1)
                                #------
                                print (Time_Left,"\n")
                                Time_Left = Time_Left -1
                                time.sleep(1)
                                print ("\n")
                                Login_T()
                            elif Doctor_Password_Verify != Doctor_Password:
                                print (" ")
                                print ("Please make sure both passwords are correct: ")
                elif Register == ("Patient") or Register == ("patient") or Register == ("P") or Register == ("p"):
                    def Patient_MAIN():
                        def Patient_Register():
                            Break = 0
                            x = 0
                            while x == 0:
                                print ("\n")
                                Patient_First_Name = input("Please enter your first name: ").capitalize()
                                print ("\n")
                                print ("So your name is",Patient_First_Name,"?")
                                print ("\n")
                                True_False1 = input("Is this correct [Y]/[N]: ").upper()
                                if True_False1 == ("Y"):
                                    x = 1
                                    print ("\n")
                                    Patient_Last_Name = input("Please enter your last name: ").capitalize()
                                    print ("\n")
                                    print ("So your last name is",Patient_Last_Name,"?")
                                    print ("\n")
                                    True_False2 = input("Is this correct [Y]/[N]: ").capitalize()
                                    if True_False2 == ("Y"):
                                        print ("\n")
                                        print ("Welcome",Patient_First_Name,Patient_Last_Name,"!")
                                        print ("\n")
                                        x = 0
                                        while x == 0:
                                            Patient_Username1 = input("Please create a username: ").capitalize()
                                            print ("\n")
                                            print ("Username:",Patient_Username1)
                                            Patient_User.append(Patient_Username1)
                                            x = 1
                                            print ("\n")
                                            x = 0
                                            while x == 0:
                                                Patient_Password_Reg = input("Please create a password: ")
                                                print ("\n")
                                                print ("Password:",Patient_Password_Reg)
                                                print ("\n")
                                                True_False3 = input("Please re-enter your password: ")
                                                if True_False3 == (Patient_Password_Reg):
                                                    print ("\n")
                                                    Patient_Password.append(Patient_Password_Reg)
                                                    x = 1
                                                    print ("\n")
                                                    print ("Alright! Your account is now set",Patient_First_Name,",",Patient_Last_Name,"!","\n")
                                                    Time_Left = 5
                                                    print ("Redirection to the main menu in: \n")
                                                    print (Time_Left,"\n")
                                                    Time_Left = Time_Left -1
                                                    time.sleep(1)
                                                    #------
                                                    print (Time_Left,"\n")
                                                    Time_Left = Time_Left -1
                                                    time.sleep(1)
                                                    #------
                                                    print (Time_Left,"\n")
                                                    Time_Left = Time_Left -1
                                                    time.sleep(1)
                                                    #------
                                                    print (Time_Left,"\n")
                                                    Time_Left = Time_Left -1
                                                    time.sleep(1)
                                                    #------
                                                    print (Time_Left,"\n")
                                                    Time_Left = Time_Left -1
                                                    time.sleep(1)
                                                    print ("\n")
                                                    Login_T()
                                                else:
                                                    print ("Please re-enter your password: ")
                                                    print ("\n")
                                                    Break = Break + 1
                                                    if Break == 3:
                                                        x = 1
                                                        print ("\n")
                                                        print ("You have entered the wrong password",Break," amount of times so the code has ended.")
                                                        break
                                    elif True_False2 == ("N"):
                                        print ("\n")
                                        Patient_Register()
                                elif True_False1 == ("N"):
                                    x = 1
                                    print ("\n")
                                    Patient_Register()
                                else:
                                    print ("Please enter either [Y]/[N]: ")
                                    print ("\n")
                        Patient_Register()
                    Patient_MAIN()
            else:
                print ("\n")
                print ("Please enter either [Yes]/[No] to continue: ")
                print ("\n")
    Login_T()
Login_F()