def Patient_Database():
    print (" ")
    print ("Hello!")
    print (" ")
    x = 0
    while x == 0:
        U = input("Type in [1]: ")
        if U == ("1"):
            print ("Nice bro, you passed the test!")
Patient_Database()