ABC_List = [""]
try:
    with open('abc_list.txt') as abc_list_file:
        abc_list = [value.strip() for value in abc_list_file]
        with open('abc_list.txt', 'w') as abc_list_file:
            abc_list_file.writelines(abc_list)
except IOError:
    abc_list = []
